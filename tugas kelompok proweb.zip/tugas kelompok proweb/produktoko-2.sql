-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 13, 2025 at 04:58 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `produktoko`
--

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id` int(11) NOT NULL,
  `nama_produk` varchar(100) DEFAULT NULL,
  `stok` int(11) DEFAULT NULL,
  `harga` int(11) DEFAULT 0,
  `tanggal_masuk` date DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `supplier` varchar(255) DEFAULT NULL,
  `kategori` varchar(255) DEFAULT NULL,
  `keterangan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id`, `nama_produk`, `stok`, `harga`, `tanggal_masuk`, `deskripsi`, `supplier`, `kategori`, `keterangan`) VALUES
(4, 'minyak', 86, 12500, '2025-06-28', 'Bimoli', 'PT.Bimoli', '1Liter', ''),
(6, 'tepung', 100, 10000, '2025-07-07', 'Tepung beras', 'PT.tepung', '1kg', NULL),
(7, 'Surya', 0, 26500, '2025-07-06', 'Merah', 'PT.GudangGaram', 'Surya Isi 12', NULL),
(8, 'Malboro', 10, 25000, '2025-07-06', 'Marlong', 'PT.GudangGaram', 'isi 12', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('admin','petugas','viewer') DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `role`, `created_at`) VALUES
(3, 'wisnu', '$2y$10$g2AfhkRYqzB8rOc36UJ3H.mQkbMHSA2VbpcOwPnfvzrRMbfCdGqNq', 'admin', '2025-07-05 16:22:03'),
(5, 'cleo', '$2y$10$ABnIYMsN1HidhFnaZSrrh.SYNEqRLdotXkU8hSEHk78sGkUoxMGqK', 'viewer', '2025-07-05 17:03:36'),
(8, 'lilcholu', '$2y$10$WmG1sn421CfZFUVqraLu7uKhoaV.iEA9wYKddaTQJGAxCmw9HCjea', 'petugas', '2025-07-06 15:27:25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
