<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Produk extends CI_Controller {

  public function __construct() {
    parent::__construct();
    $this->load->model('Produk_model');
    $this->load->library(['session', 'form_validation']); // Tambahkan 'form_validation' di sini
    $this->load->helper(['url', 'form']);

    // Cek apakah sudah login
    if (!$this->session->userdata('username')) {
      redirect('auth/login');
    }
  }

  public function index() {
    $data['produk'] = $this->Produk_model->get_all();
    $this->load->view('produk/index', $data);
  }

  public function create() {
    $this->check_access(['admin', 'petugas']);

    // Atur aturan validasi untuk semua kolom
    $this->form_validation->set_rules('nama_produk', 'Nama Produk', 'required');
    $this->form_validation->set_rules('stok', 'Stok', 'required|numeric');
    $this->form_validation->set_rules('harga', 'Harga', 'required|numeric');
    $this->form_validation->set_rules('tanggal_masuk', 'Tanggal Masuk', 'required'); // Tanggal masuk wajib
    $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'trim'); // Deskripsi tidak wajib
    $this->form_validation->set_rules('supplier', 'Supplier', 'trim'); // Supplier tidak wajib
    $this->form_validation->set_rules('kategori', 'Kategori', 'trim'); // Kategori tidak wajib

    if ($this->form_validation->run() == FALSE) {
      // Jika validasi gagal atau ini adalah tampilan form awal
      $this->load->view('produk/create'); // Pastikan ini mengarah ke view 'add' Anda
    } else {
      // Jika validasi berhasil, ambil data dari form
      $post = $this->input->post();
      $data = [
        'nama_produk'   => $post['nama_produk'],
        'stok'          => $post['stok'],
        'harga'         => $post['harga'] ?? 0, // Menggunakan null coalescing untuk harga default 0
        'tanggal_masuk' => $post['tanggal_masuk'],
        'deskripsi'     => $post['deskripsi'],
        'supplier'      => $post['supplier'],
        'kategori'      => $post['kategori']
      ];
      $this->Produk_model->insert($data);
      $this->session->set_flashdata('success', 'Produk berhasil ditambahkan');
      redirect('produk');
    }
  }

  public function edit($id) {
    $this->check_access(['admin', 'petugas']);

    $produk = $this->Produk_model->get_by_id($id);
    if (!$produk) {
      show_404();
    }

    // Atur aturan validasi untuk semua kolom
    $this->form_validation->set_rules('nama_produk', 'Nama Produk', 'required');
    $this->form_validation->set_rules('stok', 'Stok', 'required|numeric');
    $this->form_validation->set_rules('harga', 'Harga', 'required|numeric');
    $this->form_validation->set_rules('tanggal_masuk', 'Tanggal Masuk', 'required');
    $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'trim');
    $this->form_validation->set_rules('supplier', 'Supplier', 'trim');
    $this->form_validation->set_rules('kategori', 'Kategori', 'trim');

    if ($this->form_validation->run() == FALSE) {
      // Jika validasi gagal atau ini adalah tampilan form awal
      $data['produk'] = $produk; // Kirim data produk yang sudah ada ke view
      $this->load->view('produk/edit', $data);
    } else {
      // Jika validasi berhasil, ambil data dari form
      $post = $this->input->post();
      $data = [
        'nama_produk'   => $post['nama_produk'],
        'stok'          => $post['stok'],
        'harga'         => $post['harga'],
        'tanggal_masuk' => $post['tanggal_masuk'],
        'deskripsi'     => $post['deskripsi'],
        'supplier'      => $post['supplier'],
        'kategori'      => $post['kategori']
      ];
      $this->Produk_model->update($id, $data);
      $this->session->set_flashdata('success', 'Produk berhasil diubah');
      redirect('produk');
    }
  }

  public function delete($id) {
    $this->check_access(['admin', 'petugas']);

    if (!$this->Produk_model->get_by_id($id)) {
      show_404();
    }

    $this->Produk_model->delete($id);
    $this->session->set_flashdata('success', 'Produk berhasil dihapus');
    redirect('produk');
  }

  private function check_access($roles) {
    $role = $this->session->userdata('role');
    if (!in_array($role, $roles)) {
      show_error('Tidak punya akses');
    }
  }
}