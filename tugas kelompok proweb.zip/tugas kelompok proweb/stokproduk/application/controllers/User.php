<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('User_model'); // Pastikan model ini ada
        $this->load->library('form_validation');
    }

    public function index() {
        $data['title'] = 'Kelola User';
        $data['users'] = $this->User_model->get_all();
        $this->load->view('user/index', $data);
    }

    public function tambah() {
        $data['title'] = 'Tambah User';

        $this->form_validation->set_rules('username', 'Username', 'required|is_unique[user.username]');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('role', 'Role', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('user/tambah', $data);
        } else {
            $this->User_model->insert([
                'username' => $this->input->post('username', true),
                'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
                'role' => $this->input->post('role')
            ]);
            redirect('user');
        }
    }
    public function delete($id) {
    $this->User_model->delete($id);
    $this->session->set_flashdata('success', 'User berhasil dihapus.');
    redirect('user');
}
     public function edit($id) {
    $data['title'] = 'Edit User';
    $data['user'] = $this->User_model->get_by_id($id);

    if (!$data['user']) {
        show_404();
    }

    $this->form_validation->set_rules('username', 'Username', 'required');
    $this->form_validation->set_rules('role', 'Role', 'required');

    if ($this->form_validation->run() == FALSE) {
        $this->load->view('user/edit', $data);
    } else {
        $update_data = [
            'username' => $this->input->post('username', true),
            'role' => $this->input->post('role')
        ];

        // Jika password diisi, update password juga
        if ($this->input->post('password')) {
            $update_data['password'] = password_hash($this->input->post('password'), PASSWORD_DEFAULT);
        }

        $this->User_model->update($id, $update_data);
        $this->session->set_flashdata('success', 'User berhasil diperbarui.');
        redirect('user');
    }
}


}
