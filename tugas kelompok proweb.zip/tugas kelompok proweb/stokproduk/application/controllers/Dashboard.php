<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

  public function __construct() {
    parent::__construct();
    if (!$this->session->userdata('username')) {
      redirect('auth/login');
    }
  }

  public function index() {
    $role = $this->session->userdata('role');

    $data = [
      'title' => 'Dashboard',
    ];

    if ($role === 'viewer') {
      $this->load->view('dashboard/viewer', $data);
    } elseif ($role === 'admin') {
      $this->load->view('dashboard/admin', $data);
    } elseif ($role === 'petugas') {
      $this->load->view('dashboard/petugas', $data);
    } else {
      show_error('Role tidak dikenali');
    }
  }
}
