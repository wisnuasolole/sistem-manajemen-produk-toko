<?php $title = 'Edit Produk'; $this->load->view('layouts/header'); ?>

<section class="content-header">
  <div class="container-fluid text-center">
    <h1 class="fw-bold"><i class="fas fa-edit text-primary"></i> Edit Produk</h1>
    <p class="text-muted">Perbarui data produk dengan teliti.</p>
  </div>
</section>

<section class="content">
  <div class="container-fluid">

    <div class="card shadow-lg border-0">
      <div class="card-body">
        <form method="post">
          <div class="row">
            <div class="col-md-6 mb-3">
              <label for="nama_produk" class="form-label">Nama Produk</label>
              <input type="text" name="nama_produk" id="nama_produk" class="form-control" required value="<?= set_value('nama_produk', $produk->nama_produk) ?>">
              <?= form_error('nama_produk', '<small class="text-danger">', '</small>') ?>
            </div>

            <div class="col-md-3 mb-3">
              <label for="stok" class="form-label">Stok</label>
              <input type="number" name="stok" id="stok" class="form-control" required value="<?= set_value('stok', $produk->stok) ?>">
              <?= form_error('stok', '<small class="text-danger">', '</small>') ?>
            </div>

            <div class="col-md-3 mb-3">
              <label for="harga" class="form-label">Harga (Rp)</label>
              <input type="number" name="harga" id="harga" class="form-control" required value="<?= set_value('harga', $produk->harga) ?>">
              <?= form_error('harga', '<small class="text-danger">', '</small>') ?>
            </div>

            <div class="col-md-4 mb-3">
              <label for="tanggal_masuk" class="form-label">Tanggal Masuk</label>
              <input type="date" name="tanggal_masuk" id="tanggal_masuk" class="form-control" required value="<?= set_value('tanggal_masuk', $produk->tanggal_masuk) ?>">
              <?= form_error('tanggal_masuk', '<small class="text-danger">', '</small>') ?>
            </div>

            <div class="col-md-8 mb-3">
              <label for="deskripsi" class="form-label">Deskripsi</label>
              <textarea name="deskripsi" id="deskripsi" class="form-control" rows="2"><?= set_value('deskripsi', $produk->deskripsi) ?></textarea>
              <?= form_error('deskripsi', '<small class="text-danger">', '</small>') ?>
            </div>

            <div class="col-md-6 mb-3">
              <label for="supplier" class="form-label">Supplier</label>
              <input type="text" name="supplier" id="supplier" class="form-control" value="<?= set_value('supplier', $produk->supplier) ?>">
              <?= form_error('supplier', '<small class="text-danger">', '</small>') ?>
            </div>

            <div class="col-md-6 mb-3">
              <label for="kategori" class="form-label">Kategori</label>
              <input type="text" name="kategori" id="kategori" class="form-control" value="<?= set_value('kategori', $produk->kategori) ?>">
              <?= form_error('kategori', '<small class="text-danger">', '</small>') ?>
            </div>
          </div>

          <div class="d-flex justify-content-end mt-4">
            <a href="<?= site_url('produk') ?>" class="btn btn-secondary me-2">
              <i class="fas fa-times"></i> Batal
            </a>
            <button type="submit" class="btn btn-success">
              <i class="fas fa-save"></i> Simpan Perubahan
            </button>
          </div>
        </form>
      </div>
    </div>

  </div>
</section>

<?php $this->load->view('layouts/footer'); ?>
