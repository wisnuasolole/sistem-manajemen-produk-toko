<?php $title = 'Data Produk'; $this->load->view('layouts/header'); ?>

<section class="content-header">
  <div class="container-fluid d-flex justify-content-between align-items-center flex-wrap">
    <div>
      <h1 class="fw-bold text-primary"><i class="fas fa-box-open me-2"></i> Data Produk</h1>
      <!-- <a href="<?= site_url('dashboard') ?>" class="btn btn-outline-secondary mt-2">
        <i class="fas fa-arrow-left me-1"></i> Kembali ke Dashboard
      </a> -->
    </div>
    <?php if ($this->session->userdata('role') != 'viewer'): ?>
      <a href="<?= site_url('produk/create') ?>" class="btn btn-primary mt-3 mt-md-0">
        <i class="fas fa-plus"></i> Tambah Produk
      </a>
    <?php endif; ?>
  </div>
</section>

<section class="content">
  <div class="container-fluid">

    <?php if ($this->session->flashdata('success')): ?>
      <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
        <i class="fas fa-check-circle me-1"></i> <?= $this->session->flashdata('success'); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    <?php endif; ?>

    <div class="card shadow-sm border-0 mt-3">
      <div class="card-body table-responsive">
        <table class="table table-bordered table-hover align-middle">
          <thead class="table-light">
            <tr>
              <th>#</th>
              <th>Nama Produk</th>
              <th>Stok</th>
              <th>Harga</th>
              <th>Tanggal Masuk</th>
              <th>Deskripsi</th>
              <th>Supplier</th>
              <th>Kategori</th>
              <th>Status</th>
              <?php if ($this->session->userdata('role') != 'viewer'): ?>
                <th>Aksi</th>
              <?php endif; ?>
            </tr>
          </thead>
          <tbody>
            <?php if (!empty($produk)): ?>
              <?php $no = 1; foreach($produk as $p): ?>
              <tr>
                <td><?= $no++ ?>.</td>
                <td><?= htmlspecialchars($p->nama_produk ?? '') ?></td>
                <td><?= htmlspecialchars($p->stok ?? '') ?></td>
                <td>Rp <?= number_format($p->harga ?? 0, 0, ',', '.') ?></td>
                <td><?= htmlspecialchars($p->tanggal_masuk ?? '') ?></td>
                <td><?= htmlspecialchars($p->deskripsi ?? '') ?></td>
                <td><?= htmlspecialchars($p->supplier ?? '') ?></td>
                <td><?= htmlspecialchars($p->kategori ?? '') ?></td>
                <td>
                  <?php
                    if (isset($p->stok)) {
                      if ($p->stok > 50) {
                        echo '<span class="badge bg-success">Tersedia</span>';
                      } elseif ($p->stok > 0) {
                        echo '<span class="badge bg-warning text-dark">Segera Habis</span>';
                      } else {
                        echo '<span class="badge bg-danger">Habis</span>';
                      }
                    }
                  ?>
                </td>
                <?php if ($this->session->userdata('role') != 'viewer'): ?>
                <td class="text-nowrap">
                  <a href="<?= site_url('produk/edit/'.$p->id) ?>" class="btn btn-warning btn-md me-1 mb-1">
                    <i class="fas fa-edit"></i> Edit
                  </a>
                  <a href="<?= site_url('produk/delete/'.$p->id) ?>" class="btn btn-danger btn-md mb-1" onclick="return confirm('Yakin ingin hapus?')">
                    <i class="fas fa-trash-alt"></i> Hapus
                  </a>
                </td>
                <?php endif; ?>
              </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr>
                <td colspan="<?= ($this->session->userdata('role') != 'viewer') ? '10' : '9' ?>" class="text-center text-muted">
                  <i class="fas fa-box-open fa-lg d-block mb-2"></i> Tidak ada data produk.
                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

  </div>
</section>

<?php $this->load->view('layouts/footer'); ?>
