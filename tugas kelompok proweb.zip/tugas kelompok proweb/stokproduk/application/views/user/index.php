<?php $this->load->view('layouts/header'); ?>

<section class="content">
  <div class="container-fluid">
    <div class="card shadow-sm border-0">
      <div class="card-header bg-primary text-white d-flex align-items-center">
        <h3 class="card-title mb-0"><i class="bi bi-person-badge me-2"></i> Daftar Pengguna</h3>
        <?php if ($this->session->userdata('role') == 'admin'): ?>
          <div class="ms-auto">
            <a href="<?= site_url('user/tambah') ?>" class="btn btn-light">
              <i class="bi bi-person-plus"></i> Tambah User
            </a>
          </div>
        <?php endif; ?>
      </div>

      <div class="card-body">
        <?php if ($this->session->flashdata('success')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle me-2"></i> <?= $this->session->flashdata('success'); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
        <?php endif; ?>

        <div class="table-responsive">
          <table class="table table-bordered table-hover align-middle">
            <thead class="table-light">
              <tr>
                <th style="width: 50px;">#</th>
                <th>Username</th>
                <th>Role</th>
                <?php if ($this->session->userdata('role') == 'admin'): ?>
                  <th class="text-center" style="width: 200px;">Aksi</th>
                <?php endif; ?>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($users)): ?>
                <?php $no = 1; foreach ($users as $u): ?>
                  <tr>
                    <td><?= $no++ ?>.</td>
                    <td><?= htmlspecialchars($u->username) ?></td>
                    <td>
                      <?php
                        $badge = 'secondary';
                        if ($u->role === 'admin') $badge = 'primary';
                        elseif ($u->role === 'petugas') $badge = 'info';
                        elseif ($u->role === 'viewer') $badge = 'warning';
                      ?>
                      <span class="badge bg-<?= $badge ?> text-uppercase"><?= $u->role ?></span>
                    </td>
                    <?php if ($this->session->userdata('role') == 'admin'): ?>
                      <td class="text-nowrap">
                        <a href="<?= site_url('user/edit/'.$u->id) ?>" class="btn btn-warning btn-md me-1 mb-1">
                          <i class="bi bi-pencil-square"></i> Edit
                        </a>
                        <a href="<?= site_url('user/delete/'.$u->id) ?>" class="btn btn-danger btn-md mb-1"
                           onclick="return confirm('Yakin ingin menghapus user <?= htmlspecialchars($u->username) ?>?')">
                          <i class="bi bi-trash"></i> Hapus
                        </a>
                      </td>
                    <?php endif; ?>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr>
                  <td colspan="<?= ($this->session->userdata('role') == 'admin') ? '4' : '3' ?>" class="text-center text-muted">
                    <i class="bi bi-exclamation-circle me-2"></i> Tidak ada data user.
                  </td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</section>

<?php $this->load->view('layouts/footer'); ?>
