<?php $this->load->view('layouts/header'); ?>

<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card shadow border-0">
        <div class="card-header bg-primary text-white text-center">
          <h4 class="mb-0"><i class="fas fa-user-plus me-2"></i> Tambah User</h4>
        </div>
        <div class="card-body">
          <form method="post">
            <div class="mb-3">
              <label for="username" class="form-label">Username</label>
              <input type="text" name="username" id="username" class="form-control" placeholder="Masukkan username" required>
              <?= form_error('username', '<small class="text-danger">', '</small>') ?>
            </div>

            <div class="mb-3">
              <label for="password" class="form-label">Password</label>
              <input type="password" name="password" id="password" class="form-control" placeholder="Masukkan password" required>
              <?= form_error('password', '<small class="text-danger">', '</small>') ?>
            </div>

            <div class="mb-3">
              <label for="role" class="form-label">Role</label>
              <select name="role" id="role" class="form-select" required>
                <option value="">-- Pilih Role --</option>
                <option value="admin">Admin</option>
                <option value="petugas">Petugas</option>
                <option value="viewer">Viewer</option>
              </select>
              <?= form_error('role', '<small class="text-danger">', '</small>') ?>
            </div>

            <div class="d-flex justify-content-between mt-4">
              <a href="<?= site_url('user') ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Kembali
              </a>
              <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Simpan
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $this->load->view('layouts/footer'); ?>
