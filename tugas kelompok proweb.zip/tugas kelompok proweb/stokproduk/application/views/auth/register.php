<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Register - Produk Toko</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="d-flex justify-content-center align-items-center vh-100 bg-light">

  <div class="card shadow-sm p-4" style="max-width: 400px; width: 100%;">
    <h4 class="mb-4 text-center text-success">
      <i class="fas fa-user-plus me-2"></i>Register Produk Toko
    </h4>

    <?php if ($this->session->flashdata('error')): ?>
      <div class="alert alert-danger"><?= $this->session->flashdata('error'); ?></div>
    <?php endif; ?>

    <form method="post">
      <div class="mb-3">
        <label for="username" class="form-label">Username</label>
        <input type="text" name="username" class="form-control" id="username" placeholder="Masukkan username" required>
      </div>

      <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" name="password" class="form-control" id="password" placeholder="Masukkan password" required>
      </div>

      <button type="submit" class="btn btn-success w-100">
        <i class="fas fa-check-circle me-2"></i>Register
      </button>
    </form>

    <p class="mt-3 text-center">
      Sudah punya akun? <a href="<?= site_url('auth/login') ?>" class="text-success text-decoration-none">Login di sini</a>
    </p>
  </div>

</body>
</html>
