<?php $title = 'Dashboard'; $this->load->view('layouts/header'); ?>

<h1>Selamat datang di Dashboard</h1>
<p>Halo, <?= $this->session->userdata('username'); ?> (<?= $this->session->userdata('role'); ?>)</p>
<a href="<?= site_url('auth/logout') ?>">Logout</a>

<?php $this->load->view('layouts/footer'); ?>
