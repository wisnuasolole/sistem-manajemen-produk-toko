<?php $this->load->view('layouts/header'); ?>

<div class="content-header">
  <div class="container-fluid text-center py-5">
    <h1 class="fw-bold text-primary mb-3"><i class="fas fa-user-shield me-2"></i> Dashboard Admin</h1>
    <p class="text-muted fs-5">Halo, <span class="fw-semibold"><?= htmlspecialchars($this->session->userdata('username')) ?></span>! Selamat datang di Dashboard Admin.</p>
    <!-- <a href="<?= site_url('auth/logout') ?>" class="btn btn-outline-danger mt-4">
      <i class="fas fa-sign-out-alt me-2"></i> Logout
    </a> -->
  </div>
</div>

<?php $this->load->view('layouts/footer'); ?>
