      </div> <!-- END .container-fluid -->
    </main>

    <footer class="app-footer">
      <strong>&copy; 2025 <a href="https://shopee.co.id/muhaidi7499" target="_blank">Data Produk</a>.</strong>
      All rights reserved.
      <span class="ms-2">Page rendered in <strong>{elapsed_time}</strong> seconds.</span>
    </footer>

  </div> <!-- END .app-wrapper -->

  <!-- Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?= base_url('assets/js/adminlte.js') ?>"></script>
</body>
</html>
