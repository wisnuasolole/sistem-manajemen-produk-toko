<aside class="app-sidebar bg-body shadow" data-bs-theme="light">
  <div class="sidebar-brand">
    <a href="<?= base_url('dashboard') ?>" class="brand-link">
      <img src="<?= base_url('assets/img/avatar.png') ?>" alt="Logo" class="brand-image opacity-75 shadow" />
      <span class="brand-text fw-light">Data Produk</span>
    </a>
  </div>

  <div class="sidebar-wrapper">
    <nav class="mt-2">
      <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu">
        <li class="nav-item">
          <a href="<?= base_url('dashboard') ?>" class="nav-link <?= ($this->uri->segment(1) == 'dashboard') ? 'active' : '' ?>">
            <i class="nav-icon bi bi-house-door"></i>
            <p>Dashboard</p>
          </a>
        </li>

        <li class="nav-item">
          <a href="<?= base_url('produk') ?>" class="nav-link <?= ($this->uri->segment(1) == 'produk') ? 'active' : '' ?>">
            <i class="nav-icon bi bi-box-seam"></i>
            <p>Kelola Produk</p>
          </a>
        </li>

        <?php if ($this->session->userdata('role') == 'admin'): ?>
        <li class="nav-item">
          <a href="<?= base_url('user') ?>" class="nav-link <?= ($this->uri->segment(1) == 'user') ? 'active' : '' ?>">
            <i class="nav-icon bi bi-people"></i>
            <p>Kelola User</p>
          </a>
        </li>
        <?php endif; ?>

        <li class="nav-item">
          <a href="<?= base_url('auth/logout') ?>" class="nav-link">
            <i class="nav-icon bi bi-box-arrow-right"></i>
            <p>Logout</p>
          </a>
        </li>
      </ul>
    </nav>
  </div>
</aside>
