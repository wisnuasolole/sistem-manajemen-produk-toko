<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {
  function get_by_username($username) {
    return $this->db->get_where('user', ['username' => $username])->row();
  }
  function insert($data) {
    $this->db->insert('user', $data);
  }
  function get_all() {
    return $this->db->get('user')->result();
  }
  function delete($id) {
    $this->db->delete('user', ['id' => $id]);
  }
  public function get_by_id($id) {
  return $this->db->get_where('user', ['id' => $id])->row();
  }
  public function update($id, $data) {
    return $this->db->where('id', $id)->update('user', $data);
  }


}
